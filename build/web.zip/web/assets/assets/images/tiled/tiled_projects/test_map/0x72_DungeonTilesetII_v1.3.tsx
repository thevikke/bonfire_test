<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="0x72_DungeonTilesetII_v1.3" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="../tileset/0x72_DungeonTilesetII_v1.3.png" width="512" height="512"/>
</tileset>
